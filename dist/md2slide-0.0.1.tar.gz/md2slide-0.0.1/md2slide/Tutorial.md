#Turorial

Place  this window to your secondary monitor or projector  
and back to the origin window, namely control window.  

You can [download](/Tutorial.md) this Tutorial.md to see how did this work.

???

This is the note area.

In the markdown file, --- is a symbol separate document to the pages of slide,
 
and that paragraphs in slides after ???  is a note of that page.

If the note area is white (on focus), press Space, Up, Down, PageUP, PageDown to change the slides both in slide window and preview window

If the note area is dark (on blur), press Space, Up, Down, PageUP, PageDown to change the slide in slide window and preview window only.

* click the note area, let it on focus.

The following is the markdown content of next page (the right part of this window)

===

#This is the next slide

you may read the left part first.

===

---

#This is the next slide

you may read the left part first.

???

Markdown(md) is good to note things down when listening a talk.

Thanks to gnab write the remark.js, the md can translate to web based slide easily.

md2slid is a tool for everyone easy to share things after listening a talk.

you can use # to tag a sentence as a title

The following is the markdown content of next page (the right part of this window)

===

# h1 title

## h2 title

### h3 title

#### h4 title

##### h5 title

###### h6 title

===

---

# h1 title

## h2 title

### h3 title

#### h4 title

##### h5 title

###### h6 title

???


Also, you can list things down quickly with -, and emphasise keywords with _ and *

The following is the markdown content of next page (the right part of this window)

===

A sentence with a lot of __important__ keywords, which you **most** be known. 

- Let's
&nbsp;&nbsp;&nbsp;&nbsp;- make 
- some
&nbsp;&nbsp;&nbsp;&nbsp;- bullet 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- and 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- points
        
===

---

A sentence with a lot of __important__ keywords, which you **most** be known. 

- Let's
    - make 
- some
    - bullet 
        - and 
            - points  
            
???

adding link and image is quit simple

The following is the markdown content of next page (the right part of this window)

===

[Link to google]('http://www.google.com')

![](http://octodex.github.com/images/octdrey-catburn.jpg)
        
===

---

[Link to google]('http://www.google.com')

![](http://octodex.github.com/images/octdrey-catburn.jpg)

???

The following is the markdown content of next page (the right part of this window)

===

# Thanks for your attention

Press the __Esc__ to close the slide.

You can learn more about markdown with [Markdown Tutorial](http://www.markdowntutorial.com/)

Also, [remark.js wiki](https://github.com/gnab/remark/wiki) provide much more layout commands.


===

---


# Thanks for your attention

Press the __Esc__ to close the slide.

You can learn more about markdown with [Markdown Tutorial](http://www.markdowntutorial.com/).

Also, [remark.js wiki](https://github.com/gnab/remark/wiki) provide much more layout commands.
